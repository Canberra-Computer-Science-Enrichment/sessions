# pgz

Notes and resources for a CCSE high school computer science enrichment class on game development with pygame-zero