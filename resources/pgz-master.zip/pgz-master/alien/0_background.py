WIDTH = 300
HEIGHT = 300

def draw():
    screen.fill((128, 0, 0))
