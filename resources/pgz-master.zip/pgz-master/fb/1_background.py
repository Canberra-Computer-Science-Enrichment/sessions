import pgzrun

TITLE = 'Flappy Bird'
WIDTH = 400
HEIGHT = 708

def draw():
    screen.blit('background', (0, 0))

pgzrun.go()

